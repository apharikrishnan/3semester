// const express=require('express')
// const router=express.Router()

// const Admin = require('../Controllers/UserController/adminController')
// const passport = require('passport')

// router.post('/register',Admin.register)
// router.get('/getUser',Admin.getUser)
// router.post('/login',Admin.login)
// router.get('/protected',passport.authenticate('jwt',{session:false}),Admin.protected)


// module.exports=router