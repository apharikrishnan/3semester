const express=require('express')
const router=express.Router()
const BusPass = require('../Controllers/buspassController')

router.post('/addBusPass',BusPass.addBusPass)
router.get('/getBusPass',BusPass.getAllBusPass)
router.post('/getUser',BusPass.getUser)


module.exports=router