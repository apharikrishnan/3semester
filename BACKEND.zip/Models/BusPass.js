const mongoose=require('mongoose')

const buspassSchema=mongoose.Schema({
    user:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'users'
    },
    yourfullname:{
        type:String,
        required:false
    },
    yourdateofbirt:{
        type:String,
        required:false
    },
    yourage:{
        type:String,
        required:false
    },
    youremailid:{
        type:String,
        required:false
    },
    yourpresentaddress:{
        type:String,
        required:false
    },
    yourmobileno:{
        type:Number,
        required:false
    },
    // end:{
    //     type:Number,
    //     required:true
    // },
    // description:{
    //     type:String
    // }

    // institution:{
    //     type:String,
    //     required:true
    // },
    // degree:{
    //     type:String,
    //     required:true
    // },
    // field:{
    //     type:String,
    //     required:true
    // },
    // grade:{
    //     type:String,
    //     required:true
    // },
    // activities:{
    //     type:String,
    //     required:true
    // },
    // start:{
    //     type:Number,
    //     required:true
    // },
    // end:{
    //     type:Number,
    //     required:true
    // },
    // description:{
    //     type:String
    // }


})

module.exports =mongoose.model('buspass',buspassSchema)